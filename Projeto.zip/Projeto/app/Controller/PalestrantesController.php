<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of InscricoesController
 *
 * @author Home
 */
class PalestrantesController extends AppController {
    //put your code here
     public $uses = array('Palestrante');
     
     
     
     public function lista() {
         
         $ordem = array('order'=>'Palestrante.nome ASC');
         $palestrante = $this->Palestrante->find('all',$ordem);
         $this->set('lista',$palestrante);
     }


     public function inserir(){
     if(!empty($this->data))
     {
        if($this->Palestrante->saveAll($this->data)){
                //$this->Session->setFlash('Inserido com sucesso');
                 $this->redirect(array('controller' => 'pages', 'action' => 'display','sucesso'));
                 
        }else{
            // $this->Session->setFlash('Erro ao Inserir');
             $this->redirect(array('controller' => 'pages', 'action' => 'display','erro'));
        }
         
     }
     }
     
        public function alterar($id = null)
    {
        $this->Palestrante->id = $id;
        if(empty($this->data))
        {
        $this->data = $this->Palestrante->read();
         
        }
        else
          { 
            //$this->data['Endereco']['contato_id'] = $this->Palestrantes->id;
              if($this->Palestrante->saveAll($this->data))
                {   
                   $this->Session->setFlash('Alterado com sucesso');
                   $this->redirect(array('action'=>'index')); 
                }
              
          }
    }
    public function excluir($id){
        if(!empty($id))
        {
            
                if($this->Palestrante->delete($id))
                {
                   $this->Session->setFlash('Excluido com sucesso');
                   $this->redirect(array('action'=>'index')); 
             
                }else
                    {

                           $this->Session->setFlash('Erro ao tentar excluir');
                           $this->redirect(array('action'=>'index')); 

                      }
        }               
    }
     public function palestrante($id = null)
     {
         $this->Palestrante->id = $id;   
         $tutor = $this->Palestrante->read();
         $this->set('visao',$tutor);  
         
     }
             
}
?>

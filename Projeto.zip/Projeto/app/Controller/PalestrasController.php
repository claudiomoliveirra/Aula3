<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of InscricoesController
 *
 * @author Home
 */
class PalestrasController extends AppController {
    //put your code here
    public $uses = array('Palestra','Palestrante');

    
    public function listaPalestrante(){
       
        $pessoa = $this->Palestrante->find('list', array('fields'=>array( 'id','nome')));
        $this->set('lista',$pessoa);
    }
    public function programacao() {
        $ordem = array('order'=>'Palestra.inicio ASC');
        
        $programacao = $this->Palestra->find('all',$ordem);
        $this->set('lista',$programacao);
    }

    public function inserir()
    {
        $this->listaPalestrante();
        
     if(!empty($this->data))
     {
        if($this->Palestra->saveAll($this->data)){
                $this->Session->setFlash('Inserido com sucesso');
                 //$this->redirect(array('controller' => 'pages', 'action' => 'display','sucesso'));
                 $this->redirect(array('action' => 'inserir'));
        }else{
             $this->Session->setFlash('Erro ao Inserir');
             $this->redirect(array('controller' => 'pages', 'action' => 'display','erro'));
        }
         
     }
    }
    
    public function alterar($id = null)
    {
        $this->Palestra->id = $id;
        if(empty($this->data))
        {
        $this->data = $this->Palestra->read();
         
        }
        else
          { 
            //$this->data['Endereco']['contato_id'] = $this->Palestra->id;
              if($this->Palestra->saveAll($this->data))
                {   
                   $this->Session->setFlash('Alterado com sucesso');
                   $this->redirect(array('action'=>'index')); 
                }
              
          }
    }
    public function excluir($id){
        if(!empty($id))
        {
            
                if($this->Palestra->delete($id))
                {
                   $this->Session->setFlash('Excluido com sucesso');
                   $this->redirect(array('action'=>'index')); 
             
                }else
                    {

                           $this->Session->setFlash('Erro ao tentar excluir');
                           $this->redirect(array('action'=>'index')); 

                      }
        }               
    }
     public function visualizar($id = null)
     {
         $this->Palestra->id = $id;   
         $paletra = $this->Palestra->read();
         $this->set('visao',$palestra);  
         
     }
             
}
?>

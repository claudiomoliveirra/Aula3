<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of InscricoesController
 *
 * @author Home
 */
class InscricoesController extends AppController {
    //put your code here
     
     public $uses = array('Inscricao');
    

     public function inserir()
    {
     if(!empty($this->data))
     {
        if($this->Inscricao->saveAll($this->data)){
                //$this->Session->setFlash('Inserido com sucesso');
                 $this->redirect(array('controller' => 'pages', 'action' => 'display','sucesso'));
                 
        }else{
            // $this->Session->setFlash('Erro ao Inserir');
             $this->redirect(array('controller' => 'pages', 'action' => 'display','erro'));
        }
         
     }
    }
    
    public function alterar($id = null)
    {
        $this->Inscricao->id = $id;
        if(empty($this->data))
        {
        $this->data = $this->Inscricao->read();
         
        }
        else
          { 
            //$this->data['Endereco']['contato_id'] = $this->Inscricao->id;
              if($this->Inscricao->saveAll($this->data))
                {   
                   $this->Session->setFlash('Alterado com sucesso');
                   $this->redirect(array('action'=>'index')); 
                }
              
          }
    }
    public function excluir($id){
        if(!empty($id))
        {
            
                if($this->Inscricao->delete($id))
                {
                   $this->Session->setFlash('Excluido com sucesso');
                   $this->redirect(array('action'=>'index')); 
             
                }else
                    {

                           $this->Session->setFlash('Erro ao tentar excluir');
                           $this->redirect(array('action'=>'index')); 

                      }
        }               
    }
     public function visualizar($id = null)
     {
         $this->Inscricao->id = $id;   
         $contato = $this->Inscricao->read();
         $this->set('visao',$contato);  
         
     }

             
}
?>

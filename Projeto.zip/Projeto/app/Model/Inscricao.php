<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Inscricao
 *
 * @author Home
 */
class Inscricao  extends AppModel{

        public $useTable ='inscricoes';
   
    }

?>

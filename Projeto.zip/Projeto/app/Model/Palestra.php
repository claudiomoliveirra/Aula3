<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Palestra
 *
 * @author Home
 */
class Palestra extends AppModel{
    
    public $useTable = 'palestras';
    
    public $belongsTo = array('Palestrante');
    
    public $validate = array(
        'nome' => array(
        'rule' => 'notEmpty',
        'message'=>"Campo deve ser preenchido!"  
        ),
        array(
        'rule' => 'isUnique',
        'message' => 'Nome já Cadastrado'    
        ),
            'descricao'=>array(
            'rule' => 'notEmpty',
            'message'=>'Campo deve ser preenchido!'  
            ),
                'inicio' => array(
                'rule' =>array('time','HH:MM'),
                'message' =>'Horario Inválido!' 

               ),
                    'fim' => array(
                    'rule' =>array('time','HH:MM'),
                    'message' =>'Horario Inválido!' 

                   )

    );
    
    
}

?>

<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Palestrante
 *
 * @author Home
 */
class Palestrante extends AppModel {
 
    public $useTable = 'palestrantes';
    
    public $hasMany = array('Palestra');
    
    public $validate = array(
            'nome'=> array(
                 'rule'=> 'notEmpty',
                 'message'=>'Campo deve ser preenchido!'
            ),
            'descricao'=> array(
                'rule'=>'notEmpty',
                'message'=>'Campo deve ser preenchido!'
            ),
                'site'=>array(
                    'rule'=>'url',  
                    'message'=>'Informe endereço válido!'    
                )
            );
    
            
}

?>
